import prompt

def run():
    inputed_name = prompt.string('May I have your name? ')
    print("Hello, " + inputed_name +'!')