# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['brain_games',
 'brain_games.scripts',
 'brain_games.scripts.chanks(old)',
 'brain_games.scripts.games']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.games.brain_calc:main',
                     'brain-even = brain_games.scripts.games.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'qqpy3ko-brain-games',
    'version': '0.3.1',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
